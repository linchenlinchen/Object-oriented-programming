//
// Created by L2595 on 2019/6/9.
//

#ifndef SOKOBAN_PLAYER_H
#define SOKOBAN_PLAYER_H


#include "Cell.h"
using namespace std;

class Player : public Cell{
    string signal = "��";
    const int index = 5;
    int row;
    int col;
public:
    Player();
    Player(int r,int c);
    void setRow(int row);
    void setCol(int col);
    int getRow();
    int getCol();
    string getSignal() override;
    virtual ~Player(){};
};


#endif //SOKOBAN_PLAYER_H
