//
// Created by L2595 on 2019/6/15.
//

#ifndef SOKOBAN_CELL_H
#define SOKOBAN_CELL_H


#include <string>
#include <iostream>

using namespace std;
class Cell {
    string signal = "";
    int index = 0;
public:
    enum{OUT_FLOOR,WALL,IN_FLOOR,BOX,Empty_GOAL,FULL_GOAL=9};
    explicit Cell(int id);
    virtual string getSignal() ;
    int getIndex();
    void setSignal(int index);
    virtual ~Cell() = default;
};






#endif //SOKOBAN_CELL_H

