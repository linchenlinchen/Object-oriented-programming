//
// Created by L2595 on 2019/6/8.
//

#ifndef SOKOBAN_CONTROLLER_H
#define SOKOBAN_CONTROLLER_H

#include <iostream>
#include "FileUtil.h"
#include "Cell.h"
#include "Player.h"
#include "Session.h"

using namespace std;

class Controller {
    Session* session = new Session(1);
public:
    void start();
    void judgeWin();
    static void printInvalid();
    static void printBye();
    static void printWelcome();
    static void printHelp();
    static void printWin();
    static void printInput();
    static void printCantMove();
    ~Controller();
};


#endif //SOKOBAN_CONTROLLER_H
