//
// Created by L2595 on 2019/6/15.
//

#include "Box.h"
Box::Box():Cell(index){row = 0,col = 0;}
Box::Box(int r,int c):row(r),col(c),Cell(index){}
void Box::setRow(int row){this->row = row;}
void Box::setCol(int col){this->col = col;}
int Box::getRow(){
    return row;
}
int Box::getCol(){
    return col;
}
string Box::getSignal()  {
return signal;
}