//
// Created by L2595 on 2019/6/5.
//

#ifndef SOKOBAN_COMMON_H
#define SOKOBAN_COMMON_H

#include <vector>
#include <string>

using namespace std;


static vector<string> split(const string& preString,const string& separator){
    string leftString = preString;
    vector<string> result;
    string::size_type pos;
    int sizeSeparator = separator.size();
    while ((pos = leftString.find(separator)) != -1){
        string partString = leftString.substr(0,pos);
        leftString = leftString.substr(pos+sizeSeparator,leftString.size()-pos);
        result.push_back(partString);
    }
    result.push_back(leftString);
    return result;
}


#endif
