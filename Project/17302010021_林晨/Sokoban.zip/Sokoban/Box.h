//
// Created by L2595 on 2019/6/15.
//

#ifndef SOKOBAN_BOX_H
#define SOKOBAN_BOX_H
#include "Cell.h"
using namespace std;

class Box : public Cell{
    string signal = "��";
    const int index = 3;
    int row;
    int col;
public:
    Box();
    Box(int r,int c);
    void setRow(int row);
    void setCol(int col);
    int getRow();
    int getCol();
    string getSignal() override;
    virtual ~Box(){}
};


#endif //SOKOBAN_BOX_H
