#include <iostream>
#include "Controller.h"
#include "Session.h"
using namespace std;


int main() {
    Controller controller;
    controller.start();
    return 0;
}