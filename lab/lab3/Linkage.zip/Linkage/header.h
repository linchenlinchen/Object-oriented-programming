
#ifndef LAB3_HEAER_H
#define LAB3_HEAER_H

static int variable = 0;
extern int variable2;
#endif //LAB3_HEAER_H
