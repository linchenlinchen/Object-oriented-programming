
#include "header.h"

void function1() {
    variable = 1;
    variable2 = 1;
}
