
#include "header.h"
void function2() {
    variable = 2;
    variable2 = 2;

}