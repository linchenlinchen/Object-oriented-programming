

#ifndef LAB3_FILE2_H
#define LAB3_FILE2_H
void function2();

#endif //LAB3_FILE2_H
