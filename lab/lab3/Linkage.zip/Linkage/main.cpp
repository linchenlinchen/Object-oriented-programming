#include <iostream>
#include "header.h"
#include "file1.h"
#include "file2.h"
int variable2;

int main() {
    function1();
    function2();

    std::cout << variable << std::endl;
    std::cout << variable2 << std::endl;
    return 0;

}