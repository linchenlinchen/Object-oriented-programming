
#ifndef LAB3_FILE1_H
#define LAB3_FILE1_H
void function1();

#endif //LAB3_FILE1_H
