console.log("Identify information 666")
namespace Information{
    var index:number = 1
    console.log("Identify information "+index)
}
namespace other{
    var index:number = 10
    console.log("Identify other "+index)
}
export interface Identify{
    print();
}