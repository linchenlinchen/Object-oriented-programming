"use strict";
exports.__esModule = true;
var Information;
(function (Information) {
    var index = 3;
    console.log("Id_student_number information " + index);
})(Information || (Information = {}));
var other;
(function (other) {
    var index = 30;
    console.log("Id_student_number other " + index);
})(other || (other = {}));
var Id_student_number = /** @class */ (function () {
    function Id_student_number() {
    }
    Id_student_number.prototype.print = function () {
        var message = "Id_student_number is printed.";
        console.log(message);
    };
    return Id_student_number;
}());
exports.Id_student_number = Id_student_number;
