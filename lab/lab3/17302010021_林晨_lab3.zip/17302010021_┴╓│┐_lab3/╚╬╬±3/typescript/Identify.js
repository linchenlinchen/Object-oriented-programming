"use strict";
exports.__esModule = true;
console.log("Identify information 666");
var Information;
(function (Information) {
    var index = 1;
    console.log("Identify information " + index);
})(Information || (Information = {}));
var other;
(function (other) {
    var index = 10;
    console.log("Identify other " + index);
})(other || (other = {}));
