#include <iostream>
#include "Area1.h"
#include "Area2.h"
int main() {
    using namespace Fuc_k;
    std::cout<<"a: "<<a<<std::endl;
    std::cout<<"b: "<<b<<std::endl;
    std::cout<<"c: "<<c<<std::endl;
    return 0;
}