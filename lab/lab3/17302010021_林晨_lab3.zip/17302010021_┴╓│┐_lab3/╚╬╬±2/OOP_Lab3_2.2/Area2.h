//
// Created by L2595 on 2019/5/8.
//

#ifndef OOP_LAB3_2_2_AREA2_H
#define OOP_LAB3_2_2_AREA2_H

namespace Fuc_k{
    int b = 3;
    int c = 4;
}
class Area2 {

};


#endif //OOP_LAB3_2_2_AREA2_H
