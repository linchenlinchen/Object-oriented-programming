//
// Created by L2595 on 2019/5/8.
//

#ifndef OOP_LAB3_2_2_AREA1_H
#define OOP_LAB3_2_2_AREA1_H

namespace Fuc_k{
    int a = 1;
    int b = 2;
}
class Area1 {

};


#endif //OOP_LAB3_2_2_AREA1_H
