package Lab1_Black_White_Chess;

//public class Piece implements Data{
//    private String signal ;
//
//    public Piece(String signal) {
//        this.signal = signal;
//    }
//
//    public String getSignal() {
//        return signal;
//    }
//
//    public void setSignal(String signal) {
//        this.signal = signal;
//    }
//
//}
