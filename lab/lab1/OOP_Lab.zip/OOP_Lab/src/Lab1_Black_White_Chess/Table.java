package Lab1_Black_White_Chess;

import java.util.ArrayList;

public class Table implements Data{
    private int scale;/*规模*/
    private String[][] table_surface;/*盘面*/
    private int[][] scores;/*分数*/
    private static ArrayList<int[]> save = new ArrayList();

    /*初始化table_surface的值*/
    void init_table(){
        for (int i = 0; i < scale; i++) {
            for (int j = 0; j < scale; j++) {
                table_surface[i][j] = DOT;
            }
        }
        table_surface[scale/2 - 1][scale/2 - 1] = table_surface[scale/2][scale/2] = O;
        table_surface[scale/2][scale/2 -1] = table_surface[scale/2 - 1][scale/2] = X;
    }

    /*静态方法取反颜色,DOT的反颜色是自己*/
    static String turn_color(String color){
        if(color.equals(X)){
            return O;
        }
        else if(color.equals(O)){
            return X;
        }
        else {
            return DOT;
        }
    }

    /*判断某个位置是否能放置本方棋子*/
    boolean can_put(int row,int col,String color){
        /*清空寻找相应位置的保存区*/
        save.clear();
        boolean can_put = false;
        /*若原本该位置有棋子就不能下了*/
        if(isOverBound(row,col)){
            return false;
        }
        else if(isPut(row,col)){
            return false;
        }
        /*如果这个位置还没有棋子*/
        else {
            for (int i = 0; i < 8; i++) {
                /*往外的次数*/
                int times = 1;
                int dir_row = row + times * dir[i][0];
                int dir_col = col + times * dir[i][1];
                /*对于固定某个方向的格子循环，①沿着反色棋子直到遇到未放置棋子处停止返回true，或者②始终未找到，在越界时候停止返回false*/
                /*注意，上届不仅是＜号，还减去1，原因是循环内部有一次加1操作*/
                while (dir_row >= 0 && dir_row <= this.getScale()-1 && dir_col >= 0 && dir_col <= this.getScale()-1 && turn_color(color).equals(this.getTable_surface()[dir_row][dir_col])) {
                    times++;
                    dir_row = row + times * dir[i][0];
                    dir_col = col + times * dir[i][1];
                    if(dir_row >= 0 && dir_col >=0 && dir_row <= this.getScale()-1&& dir_col <= this.getScale()-1 && color.equals(this.getTable_surface()[dir_row][dir_col])){
                        int[] dir_pos = {dir_row,dir_col};
                        save.add(dir_pos);
                        can_put = true;
                        break;
                    }
                }
            }
            return can_put;
        }
    }

    /*在人操作的时候放置，变换颜色*/
    void put(int row,int col,String color,Player player,Player offence){
        /*放上去一颗棋子，本身数目加1*/
        player.add_num(1);
        table_surface[row][col] = color;
        for (int[] dir_pos:save) {
            /*单位方向的计算*/
            int[] element = {dir_pos[0]-row ==0?0:(dir_pos[0]-row)/Math.abs(dir_pos[0]-row),dir_pos[1]-col == 0? 0 :(dir_pos[1]-col)/Math.abs(dir_pos[1]-col)};
            for (int i = 1; i < (Math.abs(dir_pos[0] - row)>0? Math.abs(dir_pos[0] - row):Math.abs(dir_pos[1] - col)); i++) {
                table_surface[row + i*element[0]][col + i*element[1]] = color;
                player.add_num(1);/*被转化的棋子*/
                offence.add_num(-1);
            }
        }
    }

    private boolean isOverBound(int row,int col){
        return row < 0 || col < 0 || row >= scale || col >= scale;
    }

    private boolean isPut(int row,int col){
        return X.equals(this.getTable_surface()[row][col]) || O.equals(this.getTable_surface()[row][col]);
    }


    /*获得规模*/
    int getScale() {
        return scale;
    }

    /*设置规模*/
    void setScale(int scale) {
        this.scale = scale;
        table_surface = new String[scale][scale];
    }

    /*获取棋盘的字符串盘面和对象盘面，以及更新操作*/
    String[][] getTable_surface() {
        return table_surface;
    }

    static ArrayList<int[]> getSave() {
        return save;
    }
}
