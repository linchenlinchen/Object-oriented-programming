package Lab1_Black_White_Chess;

public class Player {
    int piece_num = 2;
    String color;
    Server server;

    public void play(){

    }

    public int add_num(int add){
        piece_num+=add;
        return piece_num;
    }

    public Server getServer() {
        return server;
    }

    void setServer(Server server) {
        this.server = server;
    }

    int getPiece_num() {
        return piece_num;
    }
    public void setPiece_num(int piece_num) {
        this.piece_num = piece_num;
    }

    String getColor() {
        return color;
    }

    void setColor(String color) {
        this.color = color;
    }
}
