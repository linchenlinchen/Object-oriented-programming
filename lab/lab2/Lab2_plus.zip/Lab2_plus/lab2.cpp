#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <list>
#include <sstream>

using namespace std;
string get_unprocessed_code(int number);
void run_test(int);
void put_processed_code(int number, string code);
string get_unprocessed_head(const string& name);
vector<string> split(string s, string separator);
bool beginWithDefine(const string line);
bool beginWithIf(const string line);
bool beginWithIfDef(const string line);
bool beginWithUnDef(const string line);
bool beginWithIfNDef(const string line);
bool beginWithEndIf(const string line);
bool beginWithElse(const string line);
bool isDef(const string line);
void defFunc(vector<vector<string>>& def, string key,string value);
string getKey(const string line);
string getValue(const string line);
bool getBoolAfterIf(const vector<vector<string>>& def ,const string& line);
bool getBoolIfDef(const vector<vector<string>>& def, const string& line);
bool beginWithInclude(const string line);
void undefFunc(vector<vector<string>>& def, const string& line);
void handleDef(const vector<vector<string>>& def,string& line);
string getPara(const string& word);
string getFuncName(const string& word);
void specialHandleDef(const vector<vector<string>>& def,string& line);
string getValueAccordingKey(const vector<vector<string>>& def,const string& key);



int main() {
    for (int test_case_number = 1; test_case_number <= 2; test_case_number++) {
        run_test(test_case_number);
    }
    return 0;
}

void run_test(int test_case_number) {
    bool canDo = true;
    string raw_code = get_unprocessed_code(test_case_number);
    /*
     * TODO: Your Code Here!
     * TODO: Take raw_code as your input, and output your processed code.
     * TODO: You'd better create new classes to handle your logic and use here only as an entrance.
     * */
    vector<string> lines = split(raw_code,"\n");
    vector<vector<string>> def;
    int length_of_lines = lines.size();
    for (int i = 0; i < length_of_lines; ++i) {
        if(beginWithDefine(lines[i]) && canDo){
            string key = getKey(lines[i]);
            string value = getValue(lines[i]);
            defFunc(def,key,value);
        } else if(beginWithIf(lines[i]) && canDo){
            bool true_if = getBoolAfterIf(def,lines[i]);
            canDo = true_if;
        } else if(beginWithIfDef(lines[i]) && canDo){
            bool true_ifdef = getBoolIfDef(def,lines[i]);
            canDo = true_ifdef;
        } else if(beginWithIfNDef(lines[i]) && canDo){
                bool true_ifdef = getBoolIfDef(def,lines[i]);
                canDo = !true_ifdef;
        } else if(beginWithUnDef(lines[i]) && canDo){
            undefFunc(def,lines[i]);
        } else if(beginWithEndIf(lines[i])){
            canDo = true;
        } else if(beginWithElse(lines[i])) {
            canDo = !canDo;
        }
        else if(beginWithInclude(lines[i])){
            string file = split(lines[i]," ")[1];
            string::size_type finish = file.size();
            file.replace(0,1,"").replace(finish-2,1,"");
            string code = get_unprocessed_head(file);
            lines[i] = code;
        }
        else if(canDo){
            specialHandleDef(def,lines[i]);
        } else{
            lines[i].replace(0,lines[i].size(),"");
        }
        if(i == 50){
            cout<<50<<endl;
        }
    }

    string final_code;
    for (auto &line : lines) {
        if(isDef(line)){
            line.replace(0, line.size(),"");
        }
        line != ""?final_code.append(line).append("\n"):final_code;
    }

    string processed_code = final_code;
    put_processed_code(test_case_number, processed_code);
}

string get_unprocessed_code(int number) {
    string filename = "test/test" + to_string(number) + ".cpp";
    string file;
    ifstream is(filename);
    if (!is.is_open()) {
        cout << "Broken input file.";
    } else {
        string line;
        while (getline(is, line)) {
            file.append(line).push_back('\n');
        }
        is.close();
    }
    return file;
}

string get_unprocessed_head(const string& name) {
    string filename = "test/" + name;
    string file;
    ifstream is(filename);
    if (!is.is_open()) {
        cout << "Broken input file.";
    } else {
        string line;
        while (getline(is, line)) {
            file.append(line).push_back('\n');
        }
        is.close();
    }
    return file;
}

void put_processed_code(int number, string code) {
    string filename = "test/test" + to_string(number) + ".out.cpp";
    ofstream os(filename);
    if (!os.is_open()) {
        cout << "Broken output file.";
    } else {
        os << code;
        os.close();
    }
}

bool beginWithDefine(const string line){
    return line.find("#define") == 0 || line.find("# define") == 0;
}
bool beginWithIfDef(const string line){
    return line.find("#ifdef") == 0;
}
bool beginWithIf(const string line){
    return line.find("#if") == 0 && line.find("#ifdef") != 0 && line.find("#ifndef") != 0;
}
bool beginWithUnDef(const string line){
    return line.find("#undef") == 0;
}
bool beginWithIfNDef(const string line){
    return line.find("#ifndef") == 0;
}
bool beginWithEndIf(const string line){
    return line.find("#endif") == 0;
}
bool beginWithElse(const string line){
    return line.find("#else") == 0;
}
bool beginWithInclude(const string line){
    return (line.find("#include") == 0||line.find("# include") == 0) && line.find(".h")!=string::npos;
}
bool isDef(const string line){
    return line.find("#") == 0 && line != "#include \"iostream\"" && line != "#include <iostream>";
}
void defFunc(vector<vector<string>>& def,string key,string value){
    vector<string> key_val;
    key_val.push_back(key);
    key_val.push_back(value);
    def.push_back(key_val);
}
string getKey(const string line){
    if(line.find("# define") != string::npos) {
        return split(line, " ")[2];
    }
    return split(line," ")[1];
}
string getValue(const string line){
    string deal_line = line.substr(line.find("define") + 7);
    vector<string> part = split(deal_line," ");
    string result;
    if(part.size() == 1){
        return result;
    } else{
        for (int i = 1; i < part.size(); ++i) {
            result.append(part[i]).append(" ");
        }
        result.replace(result.size()-1,1,"");
    }
    return result;
}
bool getBoolAfterIf(const vector<vector<string>>& def ,const string& line){
    string condition = split(line," ")[1];
    for (const auto & i : def) {
        if(i[0] == condition && i[1] != "0"){
            return true;
        }
        if(i[0] == condition && i[1] == "0"){
            return false;
        }
    }
    return condition != "0";
}
bool getBoolIfDef(const vector<vector<string>>& def, const string& line){
    string key_to_find = split(line," ")[1];
    for (const auto & i : def) {
        if(i[0] == key_to_find){
            return true;
        }
    }
    return false;
}
void undefFunc(vector<vector<string>>& def, const string& line){
    string key_to_find = split(line," ")[1];
    vector<vector<string>>::iterator it;
    for (it = def.begin(); it != def.end() ; ++it) {
        if((*it)[0] == key_to_find){
            it = def.erase(it);
            break;
        }
    }
}
/*源于http://www.west.cn/cms/wiki/code/2018-07-20/40001.html，特此说明*/
//string myReplaceAll(const string& str, vector<string>& org_strVec, const string &rep_str) {
//    auto org_it = org_strVec.begin();
//    string org_str;
//    string target = str;
//    string strTarget = str;
//    for (; org_it != org_strVec.end(); ++org_it) {
//        org_str = *org_it;
//        vector<string> delimVec =split(strTarget, org_str);
//        target = "";
//        if (!delimVec.empty())
//        {
//            auto it = delimVec.begin();
//            for (;it != delimVec.end(); ++it)
//            {
//                target = target + (*it) +rep_str;
//            }
//            strTarget = target;
//        }
//    }
//    return strTarget;
//}
//void handleDef(const vector<vector<string>>& def,string& line){
//    for (int i = 0; i < def.size(); ++i) {
//        string::size_type pos = -1;
//        if((pos = line.find(def[i][0]))!=string::npos){
//            line.replace(pos,def[i][0].length(),def[i][1]);
//        }
//    }
//}
string getPara(const string& word){
    return word.find("(")!=string::npos? split(split(word,"(")[1],")")[0]:"";
}
string getFuncName(const string& word){
    return word.find("(")!=string::npos?split(word,"(")[0]:word;
}
string getValueAccordingKey(const vector<vector<string>>& def,const string& key){
    string::size_type pos;
    for (const auto &i : def) {
        if(i[0] == key){
            return i[1];
        } else if((pos = key.find(i[0]))!= string::npos){
            string result = key;
            result.replace(pos,i[0].size(),i[1]);
            return result;
        }
    }
    return "";
}
void specialHandleDef(const vector<vector<string>>& def,string& line){
    string param;
    string name;
    string value;
    string newValue;
    string newParam;
    string::size_type pos1;
    string::size_type pos2;
    for (const auto &i : def) {
        cout<<line.find(i[0])<<"dd:"<<i[0]<<endl;
        if(((pos1 = line.find(i[0]))!=string::npos && pos1 == 0) ||
           ((pos1 != string::npos) &&  (line[pos1-1]<'a' || line[pos1-1] >'z') && (line[pos1-1]<'A' || line[pos1-1] >'Z'))) {
            bool canContinue = true;
            string valueIterator = i[1];
            do{
                if(getValueAccordingKey(def, valueIterator).empty()){
                    canContinue = false;
                    break;
                }
                valueIterator = getValueAccordingKey(def,valueIterator);
            }while (canContinue);
            line.replace(pos1, i[0].size(), valueIterator);
        }
        name = getFuncName(i[0]);
        if((pos2 = line.find(name)) != string::npos &&
           ((pos2 == 0) ||((line[pos2-1]<'a' || line[pos2-1] >'z') && (line[pos2-1]<'A' || line[pos2-1] >'Z')))){
            param = getPara(i[0]);
            value = i[1];
            newParam = getPara(line.substr(pos2));
            pos1 = value.find(param);
            newValue = value;
            newValue = newValue.replace(pos1,param.size(),newParam);
            if((pos1 = newValue.find("#"+newParam))!=string::npos){
                newValue.replace(pos1,newParam.size()+1,"\""+newParam+"\"");
            }
            if((pos1 = newValue.find("##"))!=string::npos){
                newValue.replace(pos1,2,"");
                while ((pos1 = newValue.find(" "))!=string::npos){
                    newValue.replace(pos1,1,"");
                }
            }
            int leng = line.substr(pos2).find(")")+1;
            line.replace(pos2,leng,newValue);

        }
    }
}
//实现字符串的分割函数
vector<string> split(string s, string separator){
    vector<string> result;
    typedef string::size_type string_size;
    string_size i = 0;

    while(i != s.size()){
//        找到字符串中首个不等于分隔符的字母；
        int flag = 0;
        while(i != s.size() && flag == 0){
            flag = 1;
            for(char x : separator)
                if(s[i] == x){
                    ++i;
                    flag = 0;
                    break;
                }
        }
//        找到又一个分隔符，将两个分隔符之间的字符串取出；
        flag = 0;
        string_size j = i;
        while(j != s.size() && flag == 0){
            for(char x : separator)
                if(s[j] == x){
                    flag = 1;
                    break;
                }
            if(flag == 0)
                ++j;
        }
        if(i != j){
            result.push_back(s.substr(i, j-i));
            i = j;
        }
    }
    return result;
}

//将vector转变为字符串，且在vector的每个单独的string之间加上"\n"
string v_to_string(vector<string> strings){
    string string1;
    for(string s:strings){
        string1.append( s + "\n");
    }
    return string1;
}